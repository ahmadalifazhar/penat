<?php
/**
 * This file prevents direct access to the upload folder.
 *
 * @package	ProjectSend
 */
header("location:../index.php");
?>